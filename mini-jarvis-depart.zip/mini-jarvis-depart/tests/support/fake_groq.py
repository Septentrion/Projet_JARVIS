"""Faux serveur HTTP compatible avec l'API Groq (fourni aux étudiants).

Exemple d'utilisation :

    def test_exemple(fake_groq):
        fake_groq.script([
            fake_groq.tool_call("add_note", {"text": "acheter du lait"}),
            fake_groq.text("C'est noté."),
        ])
        # puis lancer la CLI avec GROQ_BASE_URL=fake_groq.url
        ...
        assert len(fake_groq.requests) == 2

Chaque requête reçue consomme la réponse suivante du script. Les corps JSON
des requêtes reçues sont disponibles dans fake_groq.requests.
"""

import json
import time

import pytest
from werkzeug import Request, Response

CHAT_PATH = "/openai/v1/chat/completions"


class FakeGroq:
    def __init__(self, httpserver) -> None:
        self._server = httpserver
        self._responses: list[dict] = []
        self.requests: list[dict] = []
        self._calls = 0
        httpserver.expect_request(CHAT_PATH, method="POST").respond_with_handler(self._handle)

    @property
    def url(self) -> str:
        """URL à placer dans GROQ_BASE_URL."""
        return self._server.url_for("/").rstrip("/")

    def script(self, responses: list[dict]) -> None:
        """Définit les réponses à renvoyer, dans l'ordre."""
        self._responses = list(responses)

    # --- Fabriques de réponses -------------------------------------------

    @staticmethod
    def text(content: str) -> dict:
        """Réponse finale du modèle, sans appel d'outil."""
        return {"message": {"role": "assistant", "content": content}, "finish_reason": "stop"}

    def tool_call(self, name: str, arguments: dict) -> dict:
        """Réponse du modèle qui demande l'exécution d'un outil."""
        self._calls += 1
        call = {
            "id": f"call_{self._calls}",
            "type": "function",
            "function": {"name": name, "arguments": json.dumps(arguments, ensure_ascii=False)},
        }
        message = {"role": "assistant", "content": None, "tool_calls": [call]}
        return {"message": message, "finish_reason": "tool_calls"}

    @staticmethod
    def error(status: int = 500) -> dict:
        """Erreur HTTP. Elle est renvoyée à chaque requête suivante (le SDK réessaie)."""
        return {"error": status}

    # --- Traitement des requêtes -----------------------------------------

    def _handle(self, request: Request) -> Response:
        self.requests.append(json.loads(request.get_data(as_text=True)))
        if not self._responses:
            return self._json({"error": {"message": "Aucune réponse scriptée"}}, 500)
        nxt = self._responses[0]
        if "error" in nxt:
            return self._json({"error": {"message": "Erreur simulée"}}, nxt["error"])
        self._responses.pop(0)
        body = {
            "id": f"chatcmpl-{len(self.requests)}",
            "object": "chat.completion",
            "created": int(time.time()),
            "model": self.requests[-1].get("model", "fake-model"),
            "choices": [{"index": 0, **nxt}],
            "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2},
        }
        return self._json(body, 200)

    @staticmethod
    def _json(body: dict, status: int) -> Response:
        return Response(json.dumps(body), status=status, content_type="application/json")


@pytest.fixture
def fake_groq(httpserver) -> FakeGroq:
    return FakeGroq(httpserver)

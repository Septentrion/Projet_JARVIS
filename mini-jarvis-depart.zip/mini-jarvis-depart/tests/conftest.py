"""Configuration partagée des tests (fourni).

Les marqueurs e2e et groq sont déclarés dans pyproject.toml.
"""

from support.fake_groq import fake_groq  # noqa: F401  (rend la fixture disponible partout)

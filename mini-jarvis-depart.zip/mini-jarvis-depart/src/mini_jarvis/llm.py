"""Accès au modèle de langage.

Exigences : G1 à G3 (LLMResponse, LLMClient, GroqClient).
"""

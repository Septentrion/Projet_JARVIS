"""Mini-JARVIS : un petit assistant en ligne de commande, construit en TDD."""

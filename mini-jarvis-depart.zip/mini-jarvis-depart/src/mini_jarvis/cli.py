"""Ligne de commande : jarvis ask "..."

Exigences : C1 à C4 (main, run). Lancement : python -m mini_jarvis.cli
"""

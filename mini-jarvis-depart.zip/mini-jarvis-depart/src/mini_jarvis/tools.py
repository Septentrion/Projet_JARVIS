"""Fonctions pures exposées comme outils.

Exigences : T1 à T6 (calculate, convert, now_text).
"""

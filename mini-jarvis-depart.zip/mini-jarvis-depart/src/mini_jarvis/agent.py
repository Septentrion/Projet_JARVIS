"""Boucle d'agent : message -> LLM -> outils -> LLM -> réponse.

Exigences : A1 à A6 (ToolExecutor, Agent).
"""

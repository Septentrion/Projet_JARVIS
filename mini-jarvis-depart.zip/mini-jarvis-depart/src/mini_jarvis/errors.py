"""Exceptions de Mini-JARVIS (fourni)."""


class ToolError(Exception):
    """Un outil n'a pas pu s'exécuter (entrée invalide, note introuvable...)."""


class ParsingError(Exception):
    """Un appel d'outil renvoyé par le LLM est malformé ou invalide."""


class AgentError(Exception):
    """L'agent ne peut pas répondre (configuration absente, LLM indisponible...)."""

"""Stockage des notes dans un fichier JSON.

Exigences : N1 à N4 (NoteStore).
"""

"""Historique de conversation avec troncature.

Exigences : M1 à M5 (Conversation, default_count).
"""

"""Lecture et validation des appels d'outils renvoyés par le LLM.

Exigences : P1 à P4 (ToolCall, parse_tool_call, validate_arguments).
"""

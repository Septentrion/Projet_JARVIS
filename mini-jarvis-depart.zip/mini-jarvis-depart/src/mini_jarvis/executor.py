"""Adaptateur entre l'agent et un serveur MCP.

Exigences : X1, X2 (mcp_tool_to_groq, MCPToolExecutor).
"""

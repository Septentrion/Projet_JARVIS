"""Serveur MCP qui expose les notes et les outils.

Exigences : S1 à S4 (build_server). Lancement : python -m mini_jarvis.mcp_server
"""

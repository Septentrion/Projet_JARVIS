# Mini-JARVIS : dépôt de départ

Ce dépôt ne contient **aucun code de production**. Vous allez tout écrire en TDD, en suivant l'énoncé du TP : un test rouge, le code minimal pour le faire passer, puis un refactoring.

## Installation

```bash
uv sync
uv run pytest
```

Le premier lancement doit afficher `no tests ran` : c'est normal, il n'y a encore aucun test.

Sans `uv` : `python -m venv .venv`, activez-le, puis `pip install -e .` et `pip install pytest pytest-httpserver pytest-mock pytest-cov`.

## Ce qui est fourni

| Fichier | Contenu |
| --- | --- |
| `src/mini_jarvis/errors.py` | Les exceptions `ToolError`, `ParsingError` et `AgentError` |
| `src/mini_jarvis/*.py` | Des modules vides ; chacun indique les exigences qu'il couvre |
| `tests/support/fake_groq.py` | La fixture `fake_groq` : un faux serveur compatible avec l'API Groq (voir sa docstring) |
| `tests/conftest.py` | Rend la fixture `fake_groq` disponible dans tous les tests |
| `pyproject.toml` | Les dépendances, la commande `jarvis` et la configuration de pytest |

Rangez vos tests dans `tests/unit/`, `tests/functional/` et `tests/e2e/`. Deux fichiers de tests ne doivent pas porter le même nom, même dans des dossiers différents.

## Commandes utiles

```bash
uv run pytest                    # tous les tests (sauf ceux marqués groq)
uv run pytest -k T1 -x           # les tests dont le nom contient T1, arrêt au premier échec
uv run pytest -m e2e             # seulement les tests de bout en bout
uv run pytest --cov=mini_jarvis  # avec la mesure de couverture
uv run pytest -m groq            # le test contre le vrai Groq (GROQ_API_KEY requise)
```

Les tests asynchrones s'écrivent simplement avec `async def test_...` : le plugin pytest d'anyio est configuré en mode automatique (`anyio_mode = "auto"`). Il fonctionne aussi pour les fixtures `async def` avec `yield`.

## Aide-mémoire du SDK MCP (version 2)

```python
from mcp import Client, StdioServerParameters
from mcp.server.mcpserver import MCPServer

server = MCPServer("mini-jarvis")

@server.tool()
def add_note(text: str) -> str:
    """La docstring devient la description de l'outil."""
    ...

# Dans un test : connexion en mémoire au serveur
async with Client(server) as client:
    outils = await client.list_tools()       # outils.tools[0].name, .input_schema
    res = await client.call_tool("add_note", {"text": "lait"})
    res.is_error, res.content[0].text

# Dans la CLI : le serveur est lancé dans un sous-processus
params = StdioServerParameters(command=sys.executable, args=["-m", "mini_jarvis.mcp_server"])
async with Client(params) as client:
    ...

server.run()  # dans mcp_server.py : sert en stdio
```

Les tutoriels plus anciens parlent de `FastMCP` et de `ClientSession` : c'est la version 1 du SDK. Dans ce TP, utilisez `MCPServer` et `Client`.

## En cas de blocage

- **S3 : le message de l'erreur n'arrive pas au client.** Lisez la documentation de `mcp.server.mcpserver.exceptions.ToolError`.
- **E1 : le serveur MCP n'écrit pas dans le bon fichier.** Regardez quelles variables d'environnement `StdioServerParameters` transmet au sous-processus.
- **Une erreur ressort dans un `ExceptionGroup`.** Une exception a traversé un bloc `async with Client(...)`. Récupérez-la à l'intérieur du bloc.
